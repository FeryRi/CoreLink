

import './App.css';
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from './context/AuthContext';  
import LogIn from './components/screens/LogIn/LogIn.jsx';
import Inicio from './components/screens/Inicio/Inicio.jsx';
import Recetas from './components/screens/Recetas/Recetas.jsx';
import Simula from './components/screens/Simula/Simula.jsx';
import Ingredientes from './components/screens/Ingredientes/Ingredientes.jsx';
import PrivateRoute from './components/PrivateRoute.jsx';  

function App() {
    return (
        <AuthProvider>  {/* Wrap the app in AuthProvider */}

                <Routes>
                    {/* Protect routes with PrivateRoute */}
                    <Route path="/Inicio" element={<PrivateRoute component={Inicio} />} />
                    <Route path="/Recetas" element={<PrivateRoute component={Recetas} />} />
                    <Route path="/Simula" element={<PrivateRoute component={Simula} />} />
                    <Route path="/Ingredientes" element={<PrivateRoute component={Ingredientes} />} />

                    {/* Login Route */}
                    <Route path="/" element={<LogIn />} />
                </Routes>

        </AuthProvider>
    );
}

export default App;
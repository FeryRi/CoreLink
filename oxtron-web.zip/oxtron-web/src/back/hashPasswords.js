import bcrypt from 'bcryptjs';

const passwords = ['admin123', 'admin456', 'admin789', 'admin321', 'admin654', 'chef123', 'chef456', 'chef789', 'chef321', 'chef654'];

async function encryptPasswords() {
  for (let i = 0; i < passwords.length; i++) {
    const hashedPassword = await bcrypt.hash(passwords[i], 10);
    console.log(`Contraseña original: ${passwords[i]}, Hash: ${hashedPassword}`);
  }
}

encryptPasswords();

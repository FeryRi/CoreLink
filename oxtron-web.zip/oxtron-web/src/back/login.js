import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import cors from 'cors';

import { supabase } from './db.js';  

const app = express();
app.use(express.json());
app.use(cors());

const JWT_SECRET = 'clave_secreta_super_segura'; 

// Ruta de login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Consulta en las tablas administrador y chef usando Supabase
    const { data: adminData, error: adminError } = await supabase
      .from('administrador')
      .select('*')
      .eq('correo', email)
      .single();

    const { data: chefData, error: chefError } = await supabase
      .from('chef')
      .select('*')
      .eq('correoCh', email)
      .single();

    let user = null;

    // Si el correo existe en administrador
    if (adminData) {
      user = adminData;
      user.role = 'admin';  
    } 
    // Si el correo existe en chef
    else if (chefData) {
      user = chefData;
      user.role = 'chef'; 
    }

    // Si no se encuentra el usuario en ninguna tabla
    if (!user) {
      return res.status(400).json({ message: 'Usuario no encontrado' });
    }

    // Obtener la contraseña encriptada (de administrador o chef)
    const passwordHash = user.contraseña || user.contraseñaCh;

    // Verificar si la contraseña existe (puede ser undefined)
    if (!passwordHash) {
      return res.status(400).json({ message: 'Contraseña no definida en la base de datos' });
    }

    // Compara la contraseña ingresada con la almacenada en la base de datos
    const validPassword = await bcrypt.compare(password, passwordHash);
    if (!validPassword) {
      return res.status(400).json({ message: 'Contraseña incorrecta' });
    }

    // Generar el token JWT
    const token = jwt.sign(
      { id: user.idadmin || user.idchef, email: user.correo || user.correoch, role: user.role },
      JWT_SECRET,
      { expiresIn: '1h' }
    );

    // Respuesta de éxito con el token
    res.json({ message: 'Login exitoso', token });
  } catch (err) {
    console.error('Error del servidor:', err);
    res.status(500).json({ message: 'Error en el servidor' });
  }
});

// Iniciar el servidor 
app.listen(4000, () => {
  console.log('Servidor corriendo en http://localhost:4000');
}
);
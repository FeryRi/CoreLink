

import { createContext, useState, useContext } from "react";

// Creacion del Auth Context
const AuthContext = createContext();

// AuthContext en componentes
export const useAuth = () => useContext(AuthContext);

// Componente AuthProvider 
export const AuthProvider = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    const login = () => {
        setIsAuthenticated(true);
    };

    const logout = () => {
        setIsAuthenticated(false);
    };

    return (
        <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};
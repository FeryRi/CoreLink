import { createContext, useState, useContext } from "react";
import { createClient } from "@supabase/supabase-js";


// Inicializa Supabase
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

// Crear el AuthContext
const AuthContext = createContext();

// Hook para usar el AuthContext en componentes
export const useAuth = () => useContext(AuthContext);

// Componente AuthProvider que envolverá la aplicación
export const AuthProvider = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [userData, setUserData] = useState(null);  

    // Función para iniciar sesión
    const login = async (email, password) => {
        try {
            // Autenticar al usuario en Supabase
            const { data: { session }, error } = await supabase.auth.signIn({ email, password });
            if (error) {
                console.error("Error en la autenticación:", error.message);
                return false; 
            }

            // Autenticación exitosa, buscar datos del usuario 
            const { data: chefData, error: chefError } = await supabase
                .from('chef')  
                .select('nombrech, apellidopach, apellidomach, correoch')
                .eq('correoch', email)  
                .single();

            if (chefError) {
                console.error("Error al obtener datos de la tabla 'chef':", chefError.message);
                return false;
            }

            // Establecer que el usuario está autenticado y guardar los datos
            setIsAuthenticated(true);
            setUserData({ ...session.user, ...chefData }); 
            return true;
        } catch (error) {
            console.error("Error al iniciar sesión:", error);
            return false;
        }
    };

    // Función para cerrar sesión
    const logout = async () => {
        await supabase.auth.signOut();
        setIsAuthenticated(false);
        setUserData(null);  // Limpiar los datos del usuario
    };

    return (
        <AuthContext.Provider value={{ isAuthenticated, userData, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

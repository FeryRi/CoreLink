import React from 'react';
import styles from "./NavBarItem.module.css";
import { useNavigate } from 'react-router-dom';
import icon1 from "./icon1.png";
import icon2 from "./icon2.png";
import icon3 from "./icon2.png";
import icon4 from "./icon4.png";
const NavBarItem = (props) => {
    const navigate = useNavigate();
    return(<div className={styles.mainContainer} onClick={()=>navigate(props.route)}>


        <div className={`${styles.icon} ${styles[props.iconFileName]} `}></div>

        <div className={`${props.isHovered ? styles.textContainer:''}`}>
            <p className={`${styles.text} ${props.isHovered ? styles.showText : ''}`}>
                {props.text}

            </p>
        </div>

    </div>)


}
export default NavBarItem
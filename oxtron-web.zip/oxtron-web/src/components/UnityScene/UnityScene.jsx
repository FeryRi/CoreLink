import React from "react";
import { Unity, useUnityContext } from "react-unity-webgl";

const UnityScene = () => {
    const { unityProvider } = useUnityContext({
        loaderUrl: "/Build/Build.loader.js",
        dataUrl: "/Build/Build.data",
        frameworkUrl: "/Build/Build.framework.js",
        codeUrl: "/Build/Build.wasm",
    });

    return (
        <div style={{display:"flex",flexDirection:"row",justifyContent:"flex-end", width: "100vw", height: "100vh", overflowY:"hidden" }}>
            <Unity unityProvider={unityProvider} style={{ width: "92.5%", height: "100%" }} />
        </div>
    );
};

export default UnityScene;

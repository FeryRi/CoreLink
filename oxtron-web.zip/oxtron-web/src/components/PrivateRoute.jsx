
    
import React from 'react';
import { useAuth } from '../context/AuthContext';

const PrivateRoute = ({ component: Component }) => {
    const { isAuthenticated } = useAuth();

    return isAuthenticated ? <Component /> : <Navigate to="/" />;
};

export default PrivateRoute;




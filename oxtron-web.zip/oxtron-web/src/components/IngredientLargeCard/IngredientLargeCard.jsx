
import React from 'react';
import styles from './IngredientLargeCard.module.css';
import trashCanIcon from './trashCanIcon.png';

const IngredientLargeCard = ({ ingrediente, onDelete }) => {
  return (
    <div className={styles.mainContainer}>
      <div className={styles.mainCardContainer}>
        {/* Nombre del Ingrediente */}
        <div className={styles.nameContainer}>
          <p>{ingrediente.nombrein}</p>
        </div>

        {/* Contenedor de Valor y Unidades */}
        <div className={styles.valueMainContainer}>
          <div className={styles.valueContentContainer}>
            <p>{ingrediente.valorcarbono}</p> {/* Valor de carbono */}
          </div>
          <div className={styles.valueUnitsContainer}>
            <p>{ingrediente.unidades}</p> {/* Unidades (Kg o Litros) */}
            <div className={styles.co2Icon}></div> {/* Ícono de CO2 */}
          </div>
        </div>
      </div>

      {/* Botón de Eliminar */}
      <button className={styles.deleteButton} onClick={() => onDelete(ingrediente.idingrediente)}>
        <img src={trashCanIcon} alt="Eliminar" /> {/* Usar la imagen del gatito tristee*/}
      </button>
    </div>
  );
};

export default IngredientLargeCard;

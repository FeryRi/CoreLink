
import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import NavBar from "../../NavBar/NavBar.jsx";
import LargeCardReceta from './largeCardReceta.jsx';
import SmallCard from './SmallCard.jsx';
import styles from "./Receta.module.css";
import SadCat from "../../IngredientLargeCard/SadCat.png"; 

// Conectar Supabase
const supabaseUrl = 'https://ujilxujylwlfyqxmwsac.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVqaWx4dWp5bHdsZnlxeG13c2FjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjc3NjA2NzIsImV4cCI6MjA0MzMzNjY3Mn0.Ms8LkpYwYCtVseSFvm0uNKhOw1KBXwZUZkCOS5Cu9y4';
const supabase = createClient(supabaseUrl, supabaseKey);

const Recetas = () => {
    const [recetas, setRecetas] = useState([]);
    const [selectedRecipe, setSelectedRecipe] = useState(null);
    const [ingredientes, setIngredientes] = useState([]);

    useEffect(() => {
        fetchRecetas();
    }, []);

    const fetchRecetas = async () => {
        try {
            const { data, error } = await supabase
                .from('receta')
                .select('idreceta, nombrere, descripcionre, co2re')
                .eq('status', 1);
            
            if (error) throw error;
            setRecetas(data);
        } catch (error) {
            console.error("Error al cargar las recetas", error);
        }
    };

    const updateRecetaStatus = async (id) => {
        try {
            await supabase
                .from('receta')
                .update({ status: 0 })
                .eq('idreceta', id);
            
            setRecetas(recetas.filter(recipe => recipe.idreceta !== id));
        } catch (error) {
            console.error("Error al cambiar el estado de la receta", error);
        }
    };

    const fetchIngredientesPorReceta = async (idReceta) => {
        try {
            const { data, error } = await supabase
                .rpc('fn_ingredientes_por_receta', { idr: idReceta });
    
            if (error) throw error;
    
            setIngredientes(data);  // Guardar los ingredientes obtenidos en el estado
        } catch (error) {
            console.error("Error al obtener ingredientes:", error);
        }
    };

    const handleRecipeSelect = async (idReceta) => {
        setSelectedRecipe(idReceta); 
        await fetchIngredientesPorReceta(idReceta);
    };

    const handlePrepareRecipe = () => {
        alert(`Preparando la receta con ID: ${selectedRecipe}`);
    };

    return (
        <div className={styles.mainContainer}>
            <NavBar />
            <div className={styles.columnsContainer}>
                {/* Left Column: Recetas */}
                <div className={styles.recipesColumn}>
                    <div className={styles.titleContainer}>
                        <p>Recetas</p>
                    </div>
                    <div className={styles.cardsContentContainer}>
                        {recetas.map((recipe) => (
                            <LargeCardReceta
                                key={recipe.idreceta}
                                recipe={{
                                    recipeName: recipe.nombrere,
                                    description: recipe.descripcionre,
                                    totalCo2: recipe.co2re !== null ? recipe.co2re : 'N/A',
                                    idreceta: recipe.idreceta
                                }}
                                onDelete={updateRecetaStatus}
                                onSelect={() => handleRecipeSelect(recipe.idreceta)}
                            />
                        ))}
                    </div>
                </div>
                
                {/* Right Column: Ingredientes */}
                <div className={styles.ingredientsColumn}>
                    <div className={styles.ingredientContainer}>
                        <h2>Ingredientes</h2>
                        {ingredientes && ingredientes.length > 0 ? (
                            ingredientes.map((ingredient) => (
                                <SmallCard
                                    key={ingredient.nombrein}
                                    name={ingredient.nombrein}
                                    portion={ingredient.valorcarbono}
                                    units={ingredient.unidades}
                                    ingredientCo2={ingredient.valorcarbono}
                                />
                            ))
                        ) : (
                            <div className={styles.noIngredientsContainer}>
                                <img src={SadCat} alt="Sad cat" className={styles.sadCatImage} />
                                <p>Uppss... esto se ve vacío,</p>
                                <p>elija una receta para ver su contenido</p>
                            </div>
                        )}

                        {/* Mostrar el botón solo si hay una receta seleccionada */}
                        {selectedRecipe && (
                            <div className={styles.buttonContainer}>
                                <button className={styles.prepareButton} onClick={handlePrepareRecipe}>
                                    Preparar 
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
 
export default Recetas;

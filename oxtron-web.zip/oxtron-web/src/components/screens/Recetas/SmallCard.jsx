
import React from 'react';
import BlueIcon from "../../IngredientLargeCard/CO2 BlueIcon.png";
import styles from './SmallCard.module.css'; 

const SmallCard = ({ name, ingredientCo2, recipeSelected, onPrepareRecipe }) => {
    const formatValue = (value, defaultValue = 'N/A') => {
        return value !== null && value !== undefined ? value : defaultValue;
    };

    return (
        <div className={styles.mainContainer}>
            <div className={styles.titleContainer}>
                <p>{formatValue(name, 'Ingrediente desconocido')}</p>
            </div>
            <div className={styles.dataContentContainer}>
                <div className={styles.co2Value}>
                    <p>{formatValue(ingredientCo2, 'No disponible')} kg</p>
                </div>
                <div className={styles.iconContainer}>
                    <img className={styles.co2Icon} src={BlueIcon} alt="co2Icon" />
                </div>
            </div>
            {/* Mostrar el botón solo si la receta está seleccionada */}
            {recipeSelected && (
                <div className={styles.buttonContainer}>
                    <button className={styles.prepareButton} onClick={onPrepareRecipe}>
                        Preparar Receta
                    </button>
                </div>
            )}
        </div>
    );
}; 

export default SmallCard;

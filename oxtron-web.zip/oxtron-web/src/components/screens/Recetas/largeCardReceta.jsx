import React, { useState } from 'react';
import styles from './largeCardLegacy.module.css';
import cloudIcon from "../../IngredientLargeCard/CO2 White Icon.png";
import trashCanIcon from '../../IngredientLargeCard/trashCanIcon.png';

const LargeCardReceta = ({ recipe, onDelete, onSelect }) => {
    const [isSelected, setIsSelected] = useState(false);

    const handleSelect = () => {
        setIsSelected(!isSelected);
        console.log('isSelected:', !isSelected);  // Verifica si el estado cambia correctamente
        onSelect();  // Llama al callback cuando se selecciona
    };

    const truncateDescription = (description) => {
        if (description.length > 20) {
            return description.substring(0, 20) + '...';
        } 
        return description;
    };

    return (
        <div
            className={`${styles.mainContainer} ${isSelected ? styles.selectedCard : ''}`}
            onClick={handleSelect}
        >
            {/* Tarjeta principal */}
            <div className={styles.mainCardContainer}>
                {/* Contenedor para nombre y descripción de la receta */}
                <div className={styles.nameAndDescriptionContainer}>
                    <div className={styles.titleContainer}>
                        <p className={styles.recipeTitle}>
                            {recipe.recipeName}
                        </p>
                    </div>
                    <div className={styles.descriptionContainer}>
                        <p className={styles.recipeDescription}>
                            {truncateDescription(recipe.description)}
                        </p>
                    </div>
                </div>

                {/* Contenedor del valor de CO2 */}
                <div className={styles.valueMainContainer}>
                    <div className={styles.valueContentContainer}>
                        <p>{recipe.totalCo2 !== 'N/A' ? recipe.totalCo2.toFixed(1) : 'N/A'}</p>
                    </div>
                    <div className={styles.valueUnitsContainer}>
                        <p>Kg</p>
                        <div className={styles.co2Icon}>
                            <img src={cloudIcon} alt="CO2 Icon" />
                        </div>
                    </div>
                </div>
            </div>

            {/* Botón de eliminar */}
            <button className={styles.deleteButton} onClick={() => onDelete(recipe.idreceta)}>
                <img src={trashCanIcon} alt="Eliminar" />
            </button>
        </div>
    );
};

export default LargeCardReceta;

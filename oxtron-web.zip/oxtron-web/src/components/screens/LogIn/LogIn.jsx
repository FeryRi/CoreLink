
import React, { useEffect, useState } from 'react';
import './Login.css';
import { createClient } from '@supabase/supabase-js';
import { useAuth } from '../../../context/AuthContext';
import { useNavigate } from 'react-router-dom'; 
import logo from '../../../assets/img/Logos/Oxtron Logo White.png'; 

// Inicializar Supabase
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

const LogIn = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [emailError, setEmailError] = useState('');
    const [passwordError, setPasswordError] = useState('');
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [message, setMessage] = useState('');

    const { isAuthenticated, login } = useAuth();
    const navigate = useNavigate();

    const Validar = async () => {
        setIsSubmitted(true);
        let valid = true;

        const validEmail = new RegExp('^[a-zA-Z0-9._:$!%-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$');

        // Validar email
        if (email === '') {
            setEmailError('Favor de ingresar su E-mail');
            valid = false;
        } else if (!validEmail.test(email)) {
            setEmailError('Favor de ingresar un E-mail válido');
            valid = false;
        } else {
            setEmailError('');
        }

        // Validacion de contrasena
        if (password === '') {
            setPasswordError('Favor de ingresar su contraseña');
            valid = false;
        } else {
            setPasswordError('');
        }

        if (valid) {
            try {
                const { data, error } = await supabase.auth.signInWithPassword({ email, password });

                if (error) {
                    setMessage(`Error: ${error.message}`);
                } else {
                    setMessage('Login exitoso');
                    login(); 
                    navigate('/Inicio'); 
                }
            } catch (error) {
                setMessage('Error en la conexión con el servidor');
            }
        }
    };

    return (
        <div>
            {/* Contenedor del logo y texto "El camino a un CERO NETO" */}
            <div className="logo-container">
                <img src={logo} alt="Oxtron Logo" className="logo-img" />
                <div className="path-to-zero">
                    EL CAMINO A UN <span className="bold">CERO NETO</span>
                </div>
            </div>

            <div className='loginMain'>
                <div className='form-style'>
                    <h2>Iniciar Sesión</h2>
                    {/* Imagen de perfil */}
                    <div className='profile-pic'></div>
                    <form name='loginForm' onSubmit={(e) => e.preventDefault()}>
                        <div className="icon-input">
                            <p className="icon">📧</p>
                            <input
                                type='email'
                                name='email'
                                placeholder='E-mail@example.com'
                                value={email}
                                onChange={(ev) => setEmail(ev.target.value)}
                            />
                        </div>
                        {isSubmitted && emailError && <p className="label-error">{emailError}</p>}

                        <div className="icon-input">
                            <p className="icon">🔒</p>
                            <input
                                type='password'
                                name='password'
                                placeholder='Contraseña'
                                value={password}
                                onChange={(ev) => setPassword(ev.target.value)}
                            />
                        </div>
                        {isSubmitted && passwordError && <p className="label-error">{passwordError}</p>}

                        <button className='button' type='button' onClick={Validar}>Acceder</button>
                    </form>

                    {message && <p className={message === 'Login exitoso' ? "success-message" : "error-message"}>{message}</p>}
                </div>
            </div>
        </div>
    );
};

export default LogIn;

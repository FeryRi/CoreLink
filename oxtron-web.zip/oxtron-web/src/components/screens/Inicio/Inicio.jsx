import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import NavBar from "../../NavBar/NavBar.jsx";
import styles from './Inicio.module.css';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

// Configuración de Supabase
const supabaseUrl = 'https://ujilxujylwlfyqxmwsac.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVqaWx4dWp5bHdsZnlxeG13c2FjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjc3NjA2NzIsImV4cCI6MjA0MzMzNjY3Mn0.Ms8LkpYwYCtVseSFvm0uNKhOw1KBXwZUZkCOS5Cu9y4';
const supabase = createClient(supabaseUrl, supabaseKey);

const Inicio = () => {
    const [platillosData, setPlatillosData] = useState([]);
    const [co2Data, setCo2Data] = useState([]);
    const [totalPlatillos, setTotalPlatillos] = useState(0); 
    const [totalCO2, setTotalCO2] = useState(0); 
    const [activePlatillosIndex, setActivePlatillosIndex] = useState(null);
    const [activeCo2Index, setActiveCo2Index] = useState(null);
    const [nombreCompleto, setNombreCompleto] = useState(''); 

    // Función para obtener datos de platillos
    async function fetchDishesData() {
        const { data, error } = await supabase.rpc('fn_total_platillos_por_dia');
        if (error) {
            console.error('Error fetching dishes data:', error);
            return [];
        }

        if (data && data.length > 0) {
            const totalPlatillos = data.reduce((acc, item) => acc + (item.total_platillos || 0), 0);
            setTotalPlatillos(totalPlatillos); 
            return data.map(item => ({
                name: item.dia_semana ? item.dia_semana.trim() : 'Sin datos',
                Platillos: item.total_platillos || 0
            }));
        } else {
            return [];
        }
    }

    // Función para obtener datos de CO2
    async function fetchCO2Data() {
        const { data, error } = await supabase.rpc('fn_total_co2_por_dia');
        if (error) {
            console.error('Error fetching CO2 data:', error);
            return [];
        }

        if (data && data.length > 0) {
            const totalCO2 = data.reduce((acc, item) => acc + (item.total_co2 || 0), 0);
            setTotalCO2(totalCO2); 
            return data.map(item => ({
                name: item.dia_semana ? item.dia_semana.trim() : 'Sin datos',
                CO2: item.total_co2 
            }));
        } else {
            return [];
        }
    }

    // Función para obtener el nombre y apellido del chef
    async function fetchChefName() {
        // Obtener el usuario autenticado
        const {
            data: { user },
            error
        } = await supabase.auth.getUser();

        if (error) {
            console.error('Error fetching user:', error);
            return;
        }

        if (user) {
            const { data, error } = await supabase
                .from('chef')  
                .select('nombrech, apellidopach') 
                .eq('correoch', user.email);  // Filtrar por el email del chef autenticado

            if (error) {
                console.error('Error fetching chef name:', error);
            } else if (data && data.length > 0) {
                const nombreCompleto = `${data[0].nombrech} ${data[0].apellidopach}`;  // Concatenamos nombre y apellido
                setNombreCompleto(nombreCompleto);  
            } else {
                console.warn('No se encontró el chef con este correo');
            }
        } else {
            console.warn('No hay usuario autenticado');
        }
    }

    // Cargar datos al montar el componente
    useEffect(() => {
        fetchChefName();  

        async function loadData() {
            const platillos = await fetchDishesData();
            const co2 = await fetchCO2Data();

            if (platillos && platillos.length > 0) {
                setPlatillosData(platillos);
            } else {
                console.warn('No se recibieron datos para la gráfica de Platillos');
            }

            if (co2 && co2.length > 0) {
                setCo2Data(co2);
            } else {
                console.warn('No se recibieron datos para la gráfica de CO2');
            }
        }

        loadData();  
    }, []);

    // Manejar el click en la gráfica de platillos
    const handlePlatillosBarClick = (data, index) => {
        setActivePlatillosIndex(index);
    };

    // Manejar el click en la gráfica de CO2
    const handleCO2BarClick = (data, index) => {
        setActiveCo2Index(index);
    };

    return (
        <div className={styles.mainContainer}>
            <NavBar />
            <div className={styles.contentContainer}>
                <div className={styles.welcomeText}>
                    <h1>Bienvenido {nombreCompleto || "Chef"}</h1> {/* Mostrar nombre y apellido del chef */}
                    <p>Cada platillo no solo deleita tu paladar, sino también al planeta.</p>
                </div>

                {/* Contenedor para ambas gráficas */}
                <div className={styles.chartsRow}>
                    {/* Gráfico de Platillos */}
                    <div className={styles.chartWrapper}>
                        <div className={styles.chartContainer}>
                            <h2 className={styles.chartTitle}>Platillos preparados</h2>
                            <ResponsiveContainer width="100%" height={300}>
                                <BarChart data={platillosData}>
                                    <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.1} />
                                    <XAxis dataKey="name" tick={{ fontSize: 14 }} />
                                    <YAxis domain={[0, 'auto']} />
                                    <Tooltip contentStyle={{ backgroundColor: '#f4f4f4', border: 'none', borderRadius: 10 }} />
                                    <Bar 
                                        dataKey="Platillos" 
                                        fill="#87CEFA" 
                                        radius={[10, 10, 0, 0]} 
                                        animationDuration={1500}
                                        onClick={handlePlatillosBarClick}
                                    >
                                        {platillosData.map((entry, index) => (
                                            <Cell
                                                key={`cell-${index}`}
                                                fill={index === activePlatillosIndex ? '#00BFFF' : '#87CEFA'}
                                            />
                                        ))}
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                        {/* Texto debajo de la gráfica de Platillos */}
                        <p className={styles.totalText}>
                            Total de platillos elaborados: <br />
                            <span>{totalPlatillos}</span>
                        </p>
                    </div>

                    {/* Gráfico de CO2 */}
                    <div className={styles.chartWrapper}>
                        <div className={styles.chartContainer}>
                            <h2 className={styles.chartTitle}>Total de CO2 emitido por día</h2>
                            <ResponsiveContainer width="100%" height={300}>
                                <BarChart data={co2Data}>
                                    <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.1} />
                                    <XAxis dataKey="name" tick={{ fontSize: 14 }} />
                                    <YAxis domain={[0, 'auto']} />
                                    <Tooltip contentStyle={{ backgroundColor: '#f4f4f4', border: 'none', borderRadius: 10 }} />
                                    <Bar 
                                        dataKey="CO2" 
                                        fill="#003699" 
                                        radius={[10, 10, 0, 0]} 
                                        animationDuration={1500}
                                        onClick={handleCO2BarClick}
                                    >
                                        {co2Data.map((entry, index) => (
                                            <Cell
                                                key={`cell-${index}`}
                                                fill={index === activeCo2Index ? '#FF4500' : '#003699'}
                                            />
                                        ))}
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                        {/* Texto debajo de la gráfica de CO2 */}
                        <p className={styles.totalText}>
                            Total de CO2 producido: <br />
                            <span>{totalCO2} kg</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Inicio;

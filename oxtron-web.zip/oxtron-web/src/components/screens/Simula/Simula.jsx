import React from 'react';
import NavBar from "../../NavBar/NavBar.jsx";
import UnityScene from "../../UnityScene/UnityScene.jsx";
const Simula = props => {
    return(<div>
 <NavBar></NavBar>
        <UnityScene></UnityScene>
    </div>)
}
export default Simula;
import React, { useState } from 'react';
import styles from './FormularioIngrediente.module.css';

const FormularioIngrediente = ({ onAddIngredient, onCancel }) => {
  const [formData, setFormData] = useState({
    nombrein: '',
    valorcarbono: '',
    unidades: 'Kilogramos',
  });

  const [errorMessage, setErrorMessage] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.nombrein && formData.valorcarbono && formData.unidades) {
      onAddIngredient(formData);
      setFormData({ nombrein: '', valorcarbono: '', unidades: 'Kilogramos' });
      setSuccessMessage('Ingrediente agregado con éxito.');
      setTimeout(() => setSuccessMessage(null), 3000);
    } else {
      setErrorMessage('Por favor, rellena todos los campos.');
      setTimeout(() => setErrorMessage(null), 3000);
    }
  };

  return (
    <div className={styles.modalOverlay}>
      <div className={styles.formContainer}>
        {/* Botón de cerrar con una X */}
        <button className={styles.closeButton} onClick={onCancel}>
          &times;
        </button>

        <form onSubmit={handleSubmit} className={styles.form}>
          <label>
            Nombre del Ingrediente:
            <input
              type="text"
              name="nombrein"
              value={formData.nombrein}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Valor de Carbono:
            <input
              type="number"
              name="valorcarbono"
              value={formData.valorcarbono}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Unidades:
          </label>
          <div className={styles.radioGroup}>
            <label>
              <input
                type="radio"
                name="unidades"
                value="Kg"
                checked={formData.unidades === 'Kg'}
                onChange={handleInputChange}
              />
              Kilogramos
            </label>
            <label>
              <input
                type="radio"
                name="unidades"
                value="L"
                checked={formData.unidades === 'L'}
                onChange={handleInputChange}
              />
              Litros
            </label>
          </div>
          <button type="submit" className={styles.addButton}>Agregar Ingrediente</button>
        </form>
        {errorMessage && <p className={styles.errorMessage}>{errorMessage}</p>}
        {successMessage && <p className={styles.successMessage}>{successMessage}</p>}

        {/* Botón de cancelar que cierra el formulario */}
        <button className={styles.cancelButton} onClick={onCancel}>
          Cancelar
        </button>
      </div>
    </div>
  );
};

export default FormularioIngrediente;

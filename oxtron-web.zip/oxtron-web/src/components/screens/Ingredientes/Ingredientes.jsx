import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import styles from './Ingredientes.module.css';
import NavBar from '../../NavBar/NavBar.jsx';
import IngredientLargeCard from '../../IngredientLargeCard/IngredientLargeCard.jsx';
import FormularioIngrediente from './FormularioIngrediente.jsx';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft, faArrowRight } from '@fortawesome/free-solid-svg-icons';


const supabaseUrl = 'https://ujilxujylwlfyqxmwsac.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVqaWx4dWp5bHdsZnlxeG13c2FjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjc3NjA2NzIsImV4cCI6MjA0MzMzNjY3Mn0.Ms8LkpYwYCtVseSFvm0uNKhOw1KBXwZUZkCOS5Cu9y4';
const supabase = createClient(supabaseUrl, supabaseKey);

const Ingredientes = () => {
  const [ingredientes, setIngredientes] = useState([]); 
  const [filteredIngredientes, setFilteredIngredientes] = useState([]); 
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const pageSize = 100; 
  const [showAddForm, setShowAddForm] = useState(false);

  // Cargar ingredientes con paginación al cargar la página
  useEffect(() => {
    fetchIngredientes(1); 
  }, []);

  // Función para obtener ingredientes paginados de la base de datos
  const fetchIngredientes = async (page = 1) => {
    setLoading(true);
    setError(null);
    try {
      const { count: totalItems } = await supabase
        .from('ingrediente')
        .select('*', { count: 'exact', head: true });

      const totalPages = Math.ceil(totalItems / pageSize);
      setTotalPages(totalPages);

      const { data, error } = await supabase
        .from('ingrediente')
        .select('*')
        .range((page - 1) * pageSize, page * pageSize - 1);

      if (error) throw error;

      setIngredientes(data);
      setFilteredIngredientes(data); 
      setCurrentPage(page);
    } catch (error) {
      setError('Error al cargar los ingredientes');
    } finally {
      setLoading(false);
    }
  };

  // Función para buscar en toda la base de datos
  const searchIngredientes = async (searchValue) => {
    setLoading(true);
    setError(null);
    try {
      // Si no hay término de búsqueda, recargar la lista paginada
      if (searchValue.trim() === '') {
        fetchIngredientes(1); 
        return;
      }

      // Si hay un término de búsqueda, buscar en la base de datos completa
      const { data, error: searchError } = await supabase
        .from('ingrediente')
        .select('*')
        .ilike('nombrein', `%${searchValue}%`);

      if (searchError) throw searchError;

      setFilteredIngredientes(data); 
    } catch (error) {
      setError('Error al buscar el ingrediente');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // Manejar el cambio en el campo de búsqueda para buscar automáticamente
  const handleSearchChange = (e) => {
    const searchValue = e.target.value;
    setSearchTerm(searchValue);

    searchIngredientes(searchValue); 
  };

  const handleAddIngredient = async (formData) => {
    setError(null);
    try {
      const { data, error } = await supabase
        .from('ingrediente')
        .insert([formData])
        .select('*');

      if (error) throw error;

      setIngredientes([...ingredientes, data[0]]);
      setFilteredIngredientes([...ingredientes, data[0]]); 
      setShowAddForm(false);
    } catch (error) {
      setError('Error al agregar el ingrediente');
    }
  };

  const handleCancelAddIngredient = () => {
    setShowAddForm(false);
  };

  const deleteIngrediente = async (id) => {
    setIngredientes((prevIngredientes) =>
      prevIngredientes.filter((ingrediente) => ingrediente.idingrediente !== id)
    );
    setFilteredIngredientes((prevFiltered) =>
      prevFiltered.filter((ingrediente) => ingrediente.idingrediente !== id)
    );

    try {
      const { error } = await supabase
        .from('ingrediente')
        .delete()
        .eq('idingrediente', id);

      if (error) throw error;
    } catch (error) {
      setError('Error al eliminar el ingrediente de la base de datos');
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      fetchIngredientes(currentPage + 1);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      fetchIngredientes(currentPage - 1);
    }
  };

  return (
    <div className={styles.mainContainer}>
      <NavBar />

      <div className={styles.mainContentContainer}>
        <div className={styles.topContainer}>
          <div className={styles.titleContainer}>
            <p>Ingredientes</p>
            <div className={styles.addButtonContainer}>
              <button onClick={() => setShowAddForm(!showAddForm)} className={styles.customButton}>
                {showAddForm ? 'Cancelar' : 'Agregar +' }
              </button>
            </div>
          </div>

          <div className={styles.searchAndPaginationContainer}>
            <div className={styles.searchContainer}>
              <input
                type="text"
                placeholder="Buscar ingrediente..."
                value={searchTerm}
                onChange={handleSearchChange} 
                className={styles.searchInput} 
              />
            </div>

            <div className={styles.paginationContainer}>
              <button
                onClick={handlePreviousPage}
                disabled={currentPage === 1}
                className={styles.smallButton}
              >
                <FontAwesomeIcon icon={faArrowLeft} />
              </button>

              <span className={styles.paginationInfo}>
                {currentPage} / {totalPages}
              </span>

              <button
                onClick={handleNextPage}
                disabled={currentPage === totalPages}
                className={styles.smallButton}
              >
                <FontAwesomeIcon icon={faArrowRight} />
              </button>
            </div>
          </div>
        </div>

        {showAddForm && (
          <FormularioIngrediente
            onAddIngredient={handleAddIngredient}
            onCancel={handleCancelAddIngredient}
          />
        )}

        {error && <p className={styles.errorMessage}>{error}</p>}

        <div className={styles.ingredientsMainContentContainer}>
          {filteredIngredientes.length > 0 ? (
            filteredIngredientes.map((ingrediente) => (
              <IngredientLargeCard
                key={ingrediente.idingrediente}
                ingrediente={ingrediente}
                onDelete={deleteIngrediente}
              />
            ))
          ) : (
            <p>No hay ingredientes disponibles</p>
          )}

          {loading && <p>Cargando...</p>}
        </div>
      </div>
    </div>
  );
};

export default Ingredientes;

import React,{useState} from 'react';
import styles from './NavBar.module.css';
import NavBarItem from "../NavBarItem/NavBarItem.jsx";


const NavBar = () => {
    const [isHovered, setHovered] = useState(false);
    const navItems = [
        {iconFileName:"icon1", text:"Inicio",route:"/Inicio"},
        {iconFileName:"icon2", text:"Recetas",route:"/Recetas"},
        {iconFileName:"icon3", text:"Simulador",route:"/Simula"},
        {iconFileName:"icon4", text:"Ingredientes",route:"/Ingredientes"},
        {iconFileName:"icon5", text:"Salir",route:"/"},

    ];

    return(
    <div className={styles.mainContainer} onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}>
        {navItems.map(item => (
            <NavBarItem route={item.route} iconFileName={item.iconFileName} isHovered={isHovered} text={item.text} />
        ))}

    </div>
    )
}
export default NavBar;
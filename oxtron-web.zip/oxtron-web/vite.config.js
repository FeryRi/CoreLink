import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
    plugins: [react()],
    // Include these file types as assets so they are served correctly
    assetsInclude: ['**/*.data', '**/*.wasm'],
    server: {
        mimeTypes: {
            // Ensures .wasm files are served with the correct MIME type
            'application/wasm': ['wasm'],
            // Ensure .js files are treated correctly as JavaScript
            'application/javascript': ['js']
        },
    },
    build: {
        rollupOptions: {
            output: {
                assetFileNames: 'assets/[name][extname]', // Keeps asset names as they are
            },
        },
    },
});
